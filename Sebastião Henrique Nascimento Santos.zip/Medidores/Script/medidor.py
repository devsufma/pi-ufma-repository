import numpy as np
import cv2, glob

def gama(img):

    rows, cols = img.shape

    tercor = round(rows/4)
    tercoc = round(cols/4)

    for i in range(tercor-100):
        for j in range(cols):
            img[i,j] = 0
   

    for i in range(2*tercor, rows):
        for j in range(cols):
            img[i,j] = 0

    return img



if __name__ == "__main__":

    path = "../Imagens"

    for img in glob.glob(path+'/*.jpg'):
            
        kernelSize = 9;

        img2 = cv2.imread(img, 1)

        img2_gray = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)

        g = gama(img2_gray)
        
        blur = cv2.GaussianBlur(g,(kernelSize,kernelSize),0)

        c_img = cv2.Canny(blur, 100, 200)

        image, contours, hier = cv2.findContours(c_img, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

        aux = 0

        for c in contours:
            x, y, w, h = cv2.boundingRect(c)

            if(w * h > 80000):
                 continue

            if(h < 25):
                continue

            if(w >= 2*(img2.shape[1]/3)):
                continue

            if(x + w >= 2.3*(img2.shape[1]/3)):
                continue

            if(x + w <= (img2.shape[1]/3)):
                 continue

            if(y + h >= (img2.shape[0]/2)):
                continue

            rect = cv2.minAreaRect(c)
            box = cv2.boxPoints(rect)
            box = np.int0(box)
            if w > h:
                if w > aux:
                      aux = w

        
        for c in contours:
            x, y, w, h = cv2.boundingRect(c)

            rect = cv2.minAreaRect(c)
            box = cv2.boxPoints(rect)
            box = np.int0(box)

            if w == aux:
                cv2.drawContours(img2, [box], 0, (0, 0, 255), 1)
                break

        cv2.imshow("Display", img2)

        cv2.waitKey(0)
        cv2.destroyAllWindows()